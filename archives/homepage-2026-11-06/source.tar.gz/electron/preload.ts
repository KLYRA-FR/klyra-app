import { contextBridge, ipcRenderer, webUtils } from "electron";

/** L'adresse du déploiement Convex, passée par le process principal (cf. electron/compte.ts). */
const adresseConvex = process.argv.find((a) => a.startsWith("--klyra-convex="))?.slice("--klyra-convex=".length) ?? null;

/**
 * Pont entre l'interface et le système : uniquement ces fonctions, rien
 * d'autre (contextIsolation + sandbox). Les types côté interface sont dans
 * `src/lib/bridge.ts`.
 */
contextBridge.exposeInMainWorld("klyra", {
  agents: {
    list: () => ipcRenderer.invoke("agents:list"),
    /* L'équipe d'un VPS relié (serveur/equipe.mjs) : mêmes gestes que pour celle de ce PC. */
    vps: (lieu: string, methode: string, corps: unknown) => ipcRenderer.invoke("agents:vps", lieu, methode, corps),
    skillsDuPcVersVps: (lieu: string) => ipcRenderer.invoke("agents:vps:skills-du-pc", lieu),
    write: (name: string, content: string, expectedModifiedAt: number | null) =>
      ipcRenderer.invoke("agents:write", name, content, expectedModifiedAt),
    create: (name: string, content: string) => ipcRenderer.invoke("agents:create", name, content),
    installer: (name: string, content: string, origine: unknown, partage: string | null) =>
      ipcRenderer.invoke("agents:installer", name, content, origine, partage),
    appliquer: (name: string, content: string, origine: unknown, partage: string | null, expectedModifiedAt: number | null, forcer: boolean) =>
      ipcRenderer.invoke("agents:appliquer", name, content, origine, partage, expectedModifiedAt, forcer),
    mes: () => ipcRenderer.invoke("agents:mes"),
    nommerAssistant: (nom: string, teinte: string | null) => ipcRenderer.invoke("agents:mes:assistant", nom, teinte),
    activer: (name: string, actif: boolean) => ipcRenderer.invoke("agents:mes:activer", name, actif),
    ajouter: (name: string) => ipcRenderer.invoke("agents:mes:ajouter", name),
    changerOrigine: (name: string, origine: unknown) => ipcRenderer.invoke("agents:mes:origine", name, origine),
    definitionRecue: (name: string) => ipcRenderer.invoke("agents:recue", name),
    history: (name: string) => ipcRenderer.invoke("agents:history", name),
    readVersion: (name: string, id: string) => ipcRenderer.invoke("agents:version", name, id),
    readMeta: () => ipcRenderer.invoke("agents:meta:read"),
    writeMeta: (meta: unknown) => ipcRenderer.invoke("agents:meta:write", meta),
    reveal: (name: string) => ipcRenderer.invoke("agents:reveal", name),
    memoire: (agent: string, contexte: { dossier: string | null; sessionId: string | null }) => ipcRenderer.invoke("agents:memoire", agent, contexte),
    souvenir: (agent: string, contexte: { dossier: string | null; sessionId: string | null }, id: string) => ipcRenderer.invoke("agents:souvenir", agent, contexte, id),
    ecrireSouvenir: (agent: string, contexte: { dossier: string | null; sessionId: string | null }, id: string, contenu: string, attendu: number | null) =>
      ipcRenderer.invoke("agents:souvenir:ecrire", agent, contexte, id, contenu, attendu),
    creerSouvenir: (agent: string, contexte: { dossier: string | null; sessionId: string | null }, titre: string, contenu: string) =>
      ipcRenderer.invoke("agents:souvenir:creer", agent, contexte, titre, contenu),
    montrerSouvenir: (agent: string, contexte: { dossier: string | null; sessionId: string | null }, id: string | null) =>
      ipcRenderer.invoke("agents:souvenir:montrer", agent, contexte, id),
    competences: (agent: string, contexte: { dossier: string | null; lieu?: string | null }) => ipcRenderer.invoke("agents:competences", agent, contexte),
    montrerCompetence: (agent: string, contexte: { dossier: string | null }, nom: string) => ipcRenderer.invoke("agents:competence:montrer", agent, contexte, nom),
    onChange: (callback: () => void) => {
      const listener = () => callback();
      ipcRenderer.on("agents:changed", listener);
      return () => ipcRenderer.removeListener("agents:changed", listener);
    },
  },
  moteurs: {
    liste: (lieu?: string | null) => ipcRenderer.invoke("moteurs:liste", lieu ?? null),
    compte: (id: string, lieu?: string | null) => ipcRenderer.invoke("moteurs:compte", id, lieu ?? null),
    connecter: (id: string, lieu?: string | null) => ipcRenderer.invoke("moteurs:connecter", id, lieu ?? null),
    connecterAvecCle: (id: string, cle: string, lieu?: string | null) => ipcRenderer.invoke("moteurs:connecter-cle", id, cle, lieu ?? null),
    deconnecter: (id: string, lieu?: string | null) => ipcRenderer.invoke("moteurs:deconnecter", id, lieu ?? null),
    modeles: (id: string, lieu?: string | null) => ipcRenderer.invoke("moteurs:modeles", id, lieu ?? null),
    versionDisponible: (id: string, lieu?: string | null) => ipcRenderer.invoke("moteurs:version-disponible", id, lieu ?? null),
    installer: (id: string, lieu?: string | null) => ipcRenderer.invoke("moteurs:installer", id, lieu ?? null),
    mettreAJour: (id: string, lieu?: string | null) => ipcRenderer.invoke("moteurs:mettre-a-jour", id, lieu ?? null),
    utilisation: (id: string, lieu?: string | null, actualiser?: boolean, compte?: string | null) => ipcRenderer.invoke("moteurs:utilisation", id, lieu ?? null, actualiser === true, compte ?? null),
    onUtilisation: (callback: (id: string, u: unknown) => void) => {
      const listener = (_e: unknown, id: string, u: unknown) => callback(id, u);
      ipcRenderer.on("moteurs:utilisation", listener);
      return () => ipcRenderer.removeListener("moteurs:utilisation", listener);
    },
    onProgression: (callback: (id: string, p: unknown, lieu: string | null) => void) => {
      const listener = (_e: unknown, id: string, p: unknown, lieu: string | null) => callback(id, p, lieu ?? null);
      ipcRenderer.on("moteurs:progression", listener);
      return () => ipcRenderer.removeListener("moteurs:progression", listener);
    },
    onCode: (callback: (id: string, lieu: string, code: unknown) => void) => {
      const listener = (_e: unknown, id: string, lieu: string, code: unknown) => callback(id, lieu, code);
      ipcRenderer.on("moteurs:code", listener);
      return () => ipcRenderer.removeListener("moteurs:code", listener);
    },
  },
  claude: {
    status: () => ipcRenderer.invoke("claude:status"),
    run: (requestId: string, agent: string, prompt: string) => ipcRenderer.invoke("claude:run", requestId, agent, prompt),
    titre: (texte: string) => ipcRenderer.invoke("claude:titre", texte),
    essayer: (requestId: string, brouillon: unknown, cas: unknown, contexte?: unknown) => ipcRenderer.invoke("claude:essayer", requestId, brouillon, cas, contexte),
    cancel: (requestId: string) => ipcRenderer.invoke("claude:cancel", requestId),
    autoriser: (requestId: string, demandeId: string, decision: string) =>
      ipcRenderer.invoke("claude:autoriser", requestId, demandeId, decision),
    stream: (requestId: string, options: unknown) => ipcRenderer.invoke("claude:stream", requestId, options),
    onEvent: (callback: (requestId: string, event: unknown) => void) => {
      const listener = (_e: unknown, requestId: string, event: unknown) => callback(requestId, event);
      ipcRenderer.on("claude:event", listener);
      return () => ipcRenderer.removeListener("claude:event", listener);
    },
    onSpontane: (callback: (requestId: string, sessionId: string, contexte: unknown) => void) => {
      const listener = (_e: unknown, requestId: string, sessionId: string, contexte: unknown) => callback(requestId, sessionId, contexte ?? null);
      ipcRenderer.on("claude:spontane", listener);
      return () => ipcRenderer.removeListener("claude:spontane", listener);
    },
    utilisation: () => ipcRenderer.invoke("claude:utilisation"),
    compte: () => ipcRenderer.invoke("claude:compte"),
    connexion: () => ipcRenderer.invoke("claude:connexion"),
    deconnexion: () => ipcRenderer.invoke("claude:deconnexion"),
    comptes: (lieu?: string | null) => ipcRenderer.invoke("claude:comptes", lieu ?? null),
    verifierCompte: (id: string, lieu?: string | null) => ipcRenderer.invoke("claude:comptes:verifier", id, lieu ?? null),
    connecterCompte: (id?: string, lieu?: string | null) => ipcRenderer.invoke("claude:comptes:connexion", id ?? null, lieu ?? null),
    codeCompte: (id: string, code: string, lieu?: string | null) => ipcRenderer.invoke("claude:comptes:code", id, code, lieu ?? null),
    deconnecterCompte: (id: string, lieu?: string | null) => ipcRenderer.invoke("claude:comptes:deconnexion", id, lieu ?? null),
    onComptes: (callback: (lieu: string | null) => void) => {
      const listener = (_e: unknown, lieu: string | null) => callback(lieu ?? null);
      ipcRenderer.on("claude:comptes:change", listener);
      return () => ipcRenderer.removeListener("claude:comptes:change", listener);
    },
    actualiserUtilisation: () => ipcRenderer.invoke("claude:utilisation:actualiser"),
    onUtilisation: (callback: (u: unknown) => void) => {
      const listener = (_e: unknown, u: unknown) => callback(u);
      ipcRenderer.on("claude:utilisation", listener);
      return () => ipcRenderer.removeListener("claude:utilisation", listener);
    },
  },
  projets: {
    dossierExiste: (dossier: string) => ipcRenderer.invoke("projets:dossier-existe", dossier),
    choisirDossier: () => ipcRenderer.invoke("projets:choisir-dossier"),
    arbre: (dossier: string, relatif?: string, lieu?: string | null) => ipcRenderer.invoke("projets:arbre", dossier, relatif, lieu),
    creerDossierVps: (lieu: string, dossier: string) => ipcRenderer.invoke("projets:creer-dossier-vps", lieu, dossier),
    pages: (dossier: string) => ipcRenderer.invoke("projets:pages", dossier),
    lireFichier: (dossier: string, relatif: string, lieu?: string | null) => ipcRenderer.invoke("projets:lire-fichier", dossier, relatif, lieu),
    ouvrirFichier: (dossier: string, relatif: string) => ipcRenderer.invoke("projets:ouvrir-fichier", dossier, relatif),
    montrerFichier: (dossier: string, relatif: string) => ipcRenderer.invoke("projets:montrer-fichier", dossier, relatif),
    consignes: (dossier: string, nom: string, lieu?: string | null) => ipcRenderer.invoke("projets:consignes", dossier, nom, lieu ?? null),
    ecrireConsignes: (dossier: string, nom: string, lieu?: string | null) => ipcRenderer.invoke("projets:consignes:ecrire", dossier, nom, lieu ?? null),
  },
  artefacts: {
    lister: () => ipcRenderer.invoke("artefacts:lister"),
    vignette: (url: string, forcer: boolean) => ipcRenderer.invoke("artefacts:vignette", url, forcer),
    ouvrir: (url: string, titre: string) => ipcRenderer.invoke("artefacts:ouvrir", url, titre),
    etatSession: () => ipcRenderer.invoke("claude-ai:etat"),
    connecter: () => ipcRenderer.invoke("claude-ai:connexion"),
    deconnecter: () => ipcRenderer.invoke("claude-ai:deconnexion"),
  },
  rendus: {
    vignette: (chemin: string, forcer: boolean) => ipcRenderer.invoke("rendus:vignette", chemin, forcer),
    ouvrir: (chemin: string) => ipcRenderer.invoke("rendus:ouvrir", chemin),
    montrer: (chemin: string) => ipcRenderer.invoke("rendus:montrer", chemin),
    copier: (origine: string, agent: string, remplace: string | null) => ipcRenderer.invoke("rendus:copier", origine, agent, remplace),
    copierVps: (lieu: string, id: string, agent: string, nom: string, dossier: boolean, remplace: string | null) =>
      ipcRenderer.invoke("rendus:copier-vps", lieu, id, agent, nom, dossier, remplace),
    /** HTML d'une copie locale, en base64. Jamais un fichier hors des rendus. */
    lireHtml: (chemin: string) => ipcRenderer.invoke("rendus:html", chemin),
    /** HTML d'un livrable du VPS, lu sur le serveur, sans copie dans les rendus de ce PC. */
    lireHtmlVps: (lieu: string, id: string, dossier: boolean) => ipcRenderer.invoke("rendus:html-vps", lieu, id, dossier),
    /** Ouvre un livrable du VPS depuis le serveur (fichier temporaire, pas une copie gardée). */
    ouvrirVps: (lieu: string, id: string, agent: string, nom: string, dossier: boolean) =>
      ipcRenderer.invoke("rendus:ouvrir-vps", lieu, id, agent, nom, dossier),
    onVps: (callback: (lieu: string, rendu: unknown) => void) => {
      const listener = (_e: unknown, lieu: string, rendu: unknown) => callback(lieu, rendu);
      ipcRenderer.on("rendus:vps", listener);
      return () => ipcRenderer.removeListener("rendus:vps", listener);
    },
    supprimer: (chemin: string) => ipcRenderer.invoke("rendus:supprimer", chemin),
    enregistrer: (chemin: string, dossier: string | null) => ipcRenderer.invoke("rendus:enregistrer", chemin, dossier),
    dossierAgent: (agent: string, quoi: "rendus" | "atelier") => ipcRenderer.invoke("rendus:dossier-agent", agent, quoi),
  },
  documents: {
    /** Ouvre le HTML dans la fenêtre isolée. Pas d'adresse de stockage. */
    ouvrir: (html: string, titre: string) => ipcRenderer.invoke("documents:ouvrir", html, titre),
    /** Vignette PNG (data URL). `cle` est l'identifiant et la date, pas une adresse. */
    vignette: (cle: string, html: string, forcer: boolean) => ipcRenderer.invoke("documents:vignette", cle, html, forcer),
  },
  fenetres: {
    ouvrir: (url: string) => ipcRenderer.invoke("fenetres:ouvrir", url),
  },
  git: {
    etat: (dossier: string) => ipcRenderer.invoke("git:etat", dossier),
    publier: (dossier: string, message: string) => ipcRenderer.invoke("git:publier", dossier, message),
  },
  systeme: {
    utilisateur: () => ipcRenderer.invoke("systeme:utilisateur"),
    micro: () => ipcRenderer.invoke("systeme:micro"),
    sonsCoupes: () => ipcRenderer.invoke("systeme:sons-coupes"),
    notifier: (titre: string, texte: string, chatId: string, evenement?: string) =>
      ipcRenderer.invoke("systeme:notifier", titre, texte, chatId, evenement),
    /** Un clic sur une notification : la conversation à ouvrir. */
    onOuvrirChat: (callback: (chatId: string) => void) => {
      const listener = (_e: unknown, chatId: string) => callback(chatId);
      ipcRenderer.on("systeme:ouvrir-chat", listener);
      return () => ipcRenderer.removeListener("systeme:ouvrir-chat", listener);
    },
  },
  outils: {
    /** Un agent appelle un outil des fils : l'interface l'exécute et répond. */
    onAppel: (callback: (id: string, nom: string, args: Record<string, unknown>, appelant: { chatId: string; roleId: string }) => void) => {
      const listener = (_e: unknown, id: string, nom: string, args: Record<string, unknown>, appelant: { chatId: string; roleId: string }) =>
        callback(id, nom, args, appelant);
      ipcRenderer.on("outils:appel", listener);
      return () => ipcRenderer.removeListener("outils:appel", listener);
    },
    repondre: (id: string, ok: boolean, texte: string) => ipcRenderer.send("outils:reponse", id, ok, texte),
  },
  ia: {
    fournisseurs: (lieu?: string | null) => ipcRenderer.invoke("ia:fournisseurs", lieu ?? null),
    lister: (lieu?: string | null) => ipcRenderer.invoke("ia:lister", lieu ?? null),
    ajouter: (entree: unknown, lieu?: string | null) => ipcRenderer.invoke("ia:ajouter", entree, lieu ?? null),
    retirer: (id: string, lieu?: string | null) => ipcRenderer.invoke("ia:retirer", id, lieu ?? null),
    tester: (id: string, lieu?: string | null) => ipcRenderer.invoke("ia:tester", id, lieu ?? null),
  },
  mcp: {
    apps: () => ipcRenderer.invoke("mcp:apps"),
    lister: () => ipcRenderer.invoke("mcp:lister"),
    ajouter: (entree: unknown) => ipcRenderer.invoke("mcp:ajouter", entree),
    retirer: (id: string) => ipcRenderer.invoke("mcp:retirer", id),
  },
  composio: {
    etat: () => ipcRenderer.invoke("composio:etat"),
    importer: (contexte: string) => ipcRenderer.invoke("composio:importer", contexte),
    saisir: (contexte: string, cle: string) => ipcRenderer.invoke("composio:saisir", contexte, cle),
    retirer: (contexte: string) => ipcRenderer.invoke("composio:retirer", contexte),
    selectionner: (contexte: string, service: string, compte: string | null) => ipcRenderer.invoke("composio:selectionner", contexte, service, compte),
    connecter: (contexte: string, service: string, configuration: string) => ipcRenderer.invoke("composio:connecter", contexte, service, configuration),
    deconnecter: (contexte: string, compte: string) => ipcRenderer.invoke("composio:deconnecter", contexte, compte),
    console: () => ipcRenderer.invoke("composio:console"),
    connect: {
      etat: () => ipcRenderer.invoke("composio:connect:etat"),
      connecter: () => ipcRenderer.invoke("composio:connect:connecter"),
      annuler: () => ipcRenderer.invoke("composio:connect:annuler"),
      deconnecter: () => ipcRenderer.invoke("composio:connect:deconnecter"),
      vps: {
        etat: (lieu: string) => ipcRenderer.invoke("composio:connect:vps:etat", lieu),
        connecter: (lieu: string) => ipcRenderer.invoke("composio:connect:vps:connecter", lieu),
        annuler: () => ipcRenderer.invoke("composio:connect:vps:annuler"),
        deconnecter: (lieu: string) => ipcRenderer.invoke("composio:connect:vps:deconnecter", lieu),
      },
    },
  },
  planning: {
    ecrire: (markdown: string) => ipcRenderer.invoke("planning:ecrire", markdown),
  },
  dictee: {
    etat: () => ipcRenderer.invoke("dictee:etat"),
    choisirModele: (modele: string) => ipcRenderer.invoke("dictee:modele", modele),
    enregistrerCle: (cle: string) => ipcRenderer.invoke("dictee:cle", cle),
    retirerCle: () => ipcRenderer.invoke("dictee:cle-retirer"),
    testerCle: () => ipcRenderer.invoke("dictee:cle-tester"),
    prechauffer: () => ipcRenderer.invoke("dictee:prechauffer"),
    preparer: () => ipcRenderer.invoke("dictee:preparer"),
    telecharger: () => ipcRenderer.invoke("dictee:telecharger"),
    onProgression: (callback: (p: unknown) => void) => {
      const listener = (_e: unknown, p: unknown) => callback(p);
      ipcRenderer.on("dictee:progression", listener);
      return () => ipcRenderer.removeListener("dictee:progression", listener);
    },
    transcrire: (wav: Uint8Array, precedent: string) => ipcRenderer.invoke("dictee:transcrire", wav, precedent),
    ouvrir: () => ipcRenderer.invoke("dictee:ouvrir"),
    onEvenement: (callback: (id: string, e: unknown) => void) => {
      const listener = (_e: unknown, id: string, e: unknown) => callback(id, e);
      ipcRenderer.on("dictee:evenement", listener);
      return () => ipcRenderer.removeListener("dictee:evenement", listener);
    },
    envoyer: (id: string, pcm: Uint8Array, valider: boolean) => ipcRenderer.send("dictee:audio", id, pcm, valider),
    fermer: (id: string) => ipcRenderer.invoke("dictee:fermer", id),
  },
  fichiers: {
    choisir: () => ipcRenderer.invoke("fichiers:choisir"),
    montrer: (chemin: string) => ipcRenderer.invoke("fichiers:montrer", chemin),
    ecrire: (chemin: string, texte: string, lieu?: string | null) => ipcRenderer.invoke("fichiers:ecrire", chemin, texte, lieu ?? null),
    /** Chemin sur le disque d'un fichier glissé dans la fenêtre. */
    cheminDe: (file: File) => webUtils.getPathForFile(file),
    /** Une image collée (Ctrl/Cmd+V), écrite dans le dossier de l'app ; renvoie son chemin. */
    enregistrerCollage: (octets: Uint8Array, type: string) => ipcRenderer.invoke("fichiers:coller", octets, type),
    /** Une image jointe, pour sa vignette ou en grand dans le panneau. */
    image: (chemin: string, pleine: boolean) => ipcRenderer.invoke("fichiers:image", chemin, pleine),
    /** Une pièce jointe envoyée depuis le téléphone, écrite dans le dossier de l'app ; renvoie son chemin. */
    recevoirPiece: (octets: Uint8Array, nom: string) => ipcRenderer.invoke("fichiers:recevoir", octets, nom),
  },
  webhooks: {
    adresse: (secret: string) => ipcRenderer.invoke("webhooks:adresse", secret),
    onAppel: (callback: (secret: string, corps: string) => void) => {
      const listener = (_e: unknown, secret: string, corps: string) => callback(secret, corps);
      ipcRenderer.on("webhooks:appel", listener);
      return () => ipcRenderer.removeListener("webhooks:appel", listener);
    },
  },
  apercu: {
    /** L'aperçu (iframe) a changé de page : son adresse, pour la barre. */
    onAdresse: (callback: (url: string) => void) => {
      const listener = (_e: unknown, url: string) => callback(url);
      ipcRenderer.on("apercu:adresse", listener);
      return () => ipcRenderer.removeListener("apercu:adresse", listener);
    },
  },
  superagent: {
    peutOuvrir: () => ipcRenderer.invoke("superagent:peut-ouvrir"),
    ouvrir: (fait: unknown) => ipcRenderer.invoke("superagent:ouvrir", fait),
    message: (fait: unknown) => ipcRenderer.invoke("superagent:message", fait),
    etat: (filId: string) => ipcRenderer.invoke("superagent:etat", filId),
    marquer: (filId: string, status: string, controle: string | null) => ipcRenderer.invoke("superagent:marquer", filId, status, controle),
    projection: (projectId: string | null) => ipcRenderer.invoke("superagent:projection", projectId),
    preuves: (workId: string) => ipcRenderer.invoke("superagent:preuves", workId),
    chercher: (requete: string, compte: string, projectId: string | null) => ipcRenderer.invoke("superagent:chercher", requete, compte, projectId),
    preparer: (filId: string) => ipcRenderer.invoke("superagent:preparer", filId),
    /** Un passage du watchdog de l'app. Le minuteur de 15 minutes appelle la même fonction. */
    passage: () => ipcRenderer.invoke("superagent:passage"),
    /** Relie une pull request ou enregistre un fait déjà lu. N'écrit rien sur GitHub. */
    github: (fait: unknown) => ipcRenderer.invoke("superagent:github", fait),
  },
  espace: {
    lire: (lieu: string, depuis?: number) => ipcRenderer.invoke("espace:lire", lieu, depuis),
    ecrire: (lieu: string, corps: unknown) => ipcRenderer.invoke("espace:ecrire", lieu, corps),
    workflows: (lieu: string, methode: string, corps: unknown) => ipcRenderer.invoke("espace:workflows", lieu, methode, corps),
    /* Ce qu'annonce un VPS de lui-même : l'avancée d'un workflow, une notification, un espace qui a changé. */
    surEvenement: (callback: (lieu: string, event: unknown) => void) => {
      const listener = (_e: unknown, lieu: string, event: unknown) => callback(lieu, event);
      ipcRenderer.on("serveur:evenement", listener);
      return () => ipcRenderer.removeListener("serveur:evenement", listener);
    },
  },
  conversations: {
    /** L'app va se fermer : c'est le moment d'envoyer le dernier état. */
    avantFermeture: (callback: () => void) => {
      const listener = () => callback();
      ipcRenderer.on("app:avant-fermeture", listener);
      return () => ipcRenderer.removeListener("app:avant-fermeture", listener);
    },
    read: () => ipcRenderer.invoke("conversations:read"),
    write: (data: unknown) => ipcRenderer.invoke("conversations:write", data),
    exporter: (demande: { contenu: string; nomPropose: string }) => ipcRenderer.invoke("conversations:exporter", demande),
  },
  /* Routines : le moteur est dans le process principal (electron/routines/). */
  routines: {
    etat: () => ipcRenderer.invoke("routines:etat"),
    lister: (agentId?: string) => ipcRenderer.invoke("routines:lister", agentId),
    creer: (input: unknown) => ipcRenderer.invoke("routines:creer", input),
    modifier: (id: string, patch: unknown) => ipcRenderer.invoke("routines:modifier", id, patch),
    supprimer: (id: string) => ipcRenderer.invoke("routines:supprimer", id),
    executer: (id: string) => ipcRenderer.invoke("routines:executer", id),
    interrompre: (runId: string) => ipcRenderer.invoke("routines:interrompre", runId),
    historique: (id: string, limit?: number) => ipcRenderer.invoke("routines:historique", id, limit),
    prochaines: (id: string) => ipcRenderer.invoke("routines:prochaines", id),
    passages: (debut: string, fin: string) => ipcRenderer.invoke("routines:passages", debut, fin),
    apercu: (schedule: unknown, timezone: string) => ipcRenderer.invoke("routines:apercu", schedule, timezone),
    enCours: () => ipcRenderer.invoke("routines:en-cours"),
    pret: () => ipcRenderer.invoke("routines:pret"),
    signaler: (runId: string, rapport: unknown) => ipcRenderer.invoke("routines:signaler", runId, rapport),
    onLivrer: (callback: (run: unknown, routine: unknown) => void) => {
      const listener = (_e: unknown, run: unknown, routine: unknown) => callback(run, routine);
      ipcRenderer.on("routines:livrer", listener);
      return () => ipcRenderer.removeListener("routines:livrer", listener);
    },
    onAnnuler: (callback: (run: unknown) => void) => {
      const listener = (_e: unknown, run: unknown) => callback(run);
      ipcRenderer.on("routines:annuler", listener);
      return () => ipcRenderer.removeListener("routines:annuler", listener);
    },
    onChange: (callback: () => void) => {
      const listener = () => callback();
      ipcRenderer.on("routines:change", listener);
      return () => ipcRenderer.removeListener("routines:change", listener);
    },
  },
  reglages: {
    lire: () => ipcRenderer.invoke("reglages:lire"),
    ecrire: (reglages: unknown) => ipcRenderer.invoke("reglages:ecrire", reglages),
    lancement: () => ipcRenderer.invoke("reglages:lancement"),
    changerLancement: (actif: boolean) => ipcRenderer.invoke("reglages:lancement:changer", actif),
    infos: () => ipcRenderer.invoke("reglages:infos"),
    ouvrirDossier: (nom: string) => ipcRenderer.invoke("reglages:ouvrir-dossier", nom),
    diagnosticPoste: (lieu?: string | null) => ipcRenderer.invoke("reglages:diagnostic-poste", lieu ?? null),
    montrerDiagnostic: (chemin: string) => ipcRenderer.invoke("reglages:diagnostic-poste:montrer", chemin),
    skillsDisponibles: (dossier: string | null) => ipcRenderer.invoke("reglages:skills-disponibles", dossier),
    importerSkills: () => ipcRenderer.invoke("reglages:skills-importer"),
    importerSkillsPoste: () => ipcRenderer.invoke("reglages:skills-importer-poste"),
    essaiNotification: () => ipcRenderer.invoke("reglages:essai-notification"),
    autorisationsComputerUse: () => ipcRenderer.invoke("reglages:computer-use:autorisations"),
    ouvrirAutorisation: (type: string) => ipcRenderer.invoke("reglages:computer-use:ouvrir", type),
    etatComputerUse: () => ipcRenderer.invoke("reglages:computer-use:etat"),
    surEtatComputerUse: (callback: (etat: unknown) => void) => {
      const listener = (_e: unknown, etat: unknown) => callback(etat);
      ipcRenderer.on("computer-use:etat", listener);
      return () => ipcRenderer.removeListener("computer-use:etat", listener);
    },
  },
  /* Le Coffre (electron/coffre.ts) : une valeur part vers le main, jamais l'inverse. */
  coffre: {
    etat: () => ipcRenderer.invoke("coffre:etat"),
    /* Le Coffre d'un VPS : mêmes gestes ; une valeur ne revient jamais à l'écran. */
    vps: (lieu: string, methode: string, corps: unknown) => ipcRenderer.invoke("coffre:vps", lieu, methode, corps),
    copierVps: (lieu: string, id: string) => ipcRenderer.invoke("coffre:vps:copier", lieu, id),
    copierVers: (id: string, lieu: string) => ipcRenderer.invoke("coffre:copier-vers", id, lieu),
    ajouter: (entree: unknown, remplacer?: boolean) => ipcRenderer.invoke("coffre:ajouter", entree, remplacer === true),
    modifier: (id: string, champs: unknown) => ipcRenderer.invoke("coffre:modifier", id, champs),
    remplacerValeur: (id: string, valeur: string) => ipcRenderer.invoke("coffre:valeur", id, valeur),
    retirer: (id: string) => ipcRenderer.invoke("coffre:retirer", id),
    copier: (id: string) => ipcRenderer.invoke("coffre:copier", id),
    surChangement: (callback: () => void) => {
      const listener = () => callback();
      ipcRenderer.on("coffre:change", listener);
      return () => ipcRenderer.removeListener("coffre:change", listener);
    },
  },
  navigateur: {
    etat: () => ipcRenderer.invoke("navigateur:etat"),
    ouvrir: (chatId: string, url?: string) => ipcRenderer.invoke("navigateur:ouvrir", chatId, url),
    aller: (id: string, saisie: string) => ipcRenderer.invoke("navigateur:aller", id, saisie),
    historique: (id: string, geste: string) => ipcRenderer.invoke("navigateur:historique", id, geste),
    fermer: (id: string) => ipcRenderer.invoke("navigateur:fermer", id),
    afficher: (id: string | null, cadre: unknown) => ipcRenderer.invoke("navigateur:afficher", id, cadre),
    main: (id: string, prise: boolean) => ipcRenderer.invoke("navigateur:main", id, prise),
    ailleurs: (id: string) => ipcRenderer.invoke("navigateur:ailleurs", id),
    montrerTelechargement: (chemin: string) => ipcRenderer.invoke("navigateur:telechargement", chemin),
    effacer: () => ipcRenderer.invoke("navigateur:effacer"),
    actionMenu: (id: string, action: string) => ipcRenderer.invoke("navigateur:menu-action", id, action),
    onMenu: (callback: (id: string, menu: unknown) => void) => {
      const listener = (_e: unknown, id: string, menu: unknown) => callback(id, menu);
      ipcRenderer.on("navigateur:menu", listener);
      return () => ipcRenderer.removeListener("navigateur:menu", listener);
    },
    onEchap: (callback: (id: string) => void) => {
      const listener = (_e: unknown, id: string) => callback(id);
      ipcRenderer.on("navigateur:echap", listener);
      return () => ipcRenderer.removeListener("navigateur:echap", listener);
    },
    /** Test d'écran seulement : une vraie frappe Échap sur la page affichée. */
    testerEchap: () => ipcRenderer.invoke("navigateur:tester-echap"),
    /** La fenêtre qu'un agent pilote sur cet ordinateur (Computer Use), pas un onglet. */
    apercu: () => ipcRenderer.invoke("ordinateur:apercu"),
    onApercu: (callback: (etat: unknown) => void) => {
      const listener = (_e: unknown, etat: unknown) => callback(etat);
      ipcRenderer.on("ordinateur:apercu", listener);
      return () => ipcRenderer.removeListener("ordinateur:apercu", listener);
    },
    /** Test d'écran seulement. */
    testerApercu: (chatId: string, mode: string) => ipcRenderer.invoke("ordinateur:tester-apercu", chatId, mode),
    coffre: () => ipcRenderer.invoke("navigateur:coffre"),
    ajouterAuCoffre: (entree: unknown) => ipcRenderer.invoke("navigateur:coffre:ajouter", entree),
    retirerDuCoffre: (id: string) => ipcRenderer.invoke("navigateur:coffre:retirer", id),
    agentsCoffre: (id: string, agents: boolean) => ipcRenderer.invoke("navigateur:coffre:agents", id, agents),
    remplir: (id: string, idConnexion: string) => ipcRenderer.invoke("navigateur:coffre:remplir", id, idConnexion),
    onEtat: (callback: (etat: unknown) => void) => {
      const listener = (_e: unknown, etat: unknown) => callback(etat);
      ipcRenderer.on("navigateur:etat", listener);
      return () => ipcRenderer.removeListener("navigateur:etat", listener);
    },
  },
  consommation: {
    lire: () => ipcRenderer.invoke("consommation:lire"),
  },
  compte: {
    adresse: adresseConvex,
    lireJeton: (cle: string) => ipcRenderer.invoke("compte:jeton:lire", cle),
    ecrireJeton: (cle: string, valeur: string) => ipcRenderer.invoke("compte:jeton:ecrire", cle, valeur),
    retirerJeton: (cle: string) => ipcRenderer.invoke("compte:jeton:retirer", cle),
    prendreCode: () => ipcRenderer.invoke("compte:code"),
    /** Un lien klyra://connexion est arrivé : son code attend dans `prendreCode`. */
    onLien: (callback: () => void) => {
      const listener = () => callback();
      ipcRenderer.on("compte:lien", listener);
      return () => ipcRenderer.removeListener("compte:lien", listener);
    },
  },
  serveur: {
    /** Le dernier lien klyra://rejoindre, une seule fois. */
    prendreLien: () => ipcRenderer.invoke("serveur:lien"),
    /** Les appels partent du processus principal : la politique du rendu ne les coupe pas, et le jeton y reste. */
    interroger: (adresse: string) => ipcRenderer.invoke("serveur:interroger", adresse),
    appairer: (adresse: string, code: string) => ipcRenderer.invoke("serveur:appairer", adresse, code),
    retirer: (adresse: string) => ipcRenderer.invoke("serveur:retirer", adresse),
    /** Les conversations sont chargées : les réponses des VPS arrivées pendant l’absence peuvent s’ouvrir. */
    pret: () => ipcRenderer.invoke("serveur:pret"),
    onLien: (callback: () => void) => {
      const listener = () => callback();
      ipcRenderer.on("serveur:lien", listener);
      return () => ipcRenderer.removeListener("serveur:lien", listener);
    },
  },
  anthropicAdmin: {
    etat: () => ipcRenderer.invoke("anthropic-admin:etat"),
    definir: (cle: string) => ipcRenderer.invoke("anthropic-admin:definir", cle),
    retirer: () => ipcRenderer.invoke("anthropic-admin:retirer"),
    rapport: () => ipcRenderer.invoke("anthropic-admin:rapport"),
  },
  maj: {
    etat: () => ipcRenderer.invoke("maj:etat"),
    verifier: () => ipcRenderer.invoke("maj:verifier"),
    installer: () => ipcRenderer.invoke("maj:installer"),
    onEtat: (callback: (etat: unknown) => void) => {
      const listener = (_e: unknown, etat: unknown) => callback(etat);
      ipcRenderer.on("maj:etat", listener);
      return () => ipcRenderer.removeListener("maj:etat", listener);
    },
  },
});
